<?php

if ( pb_backupbuddy::_GET( 'display_mode' ) == 'embed' ) {
	pb_backupbuddy::$options['display_mode'] = 'embed';
	pb_backupbuddy::save();
}

// ********** ACTIONS (global) **********



// ********** AJAX (global) **********



// ********** CRON (global) **********



// ********** FILTERS (global) **********



// ********** WIDGETS (global) **********



?>